<?php 
	class SignupRequest extends Model{}	