<?php 
defined('C5_EXECUTE') or die("Access Denied.");
class DashboardExtendController extends Controller {

	public function view() {
		$this->redirect('/dashboard/extend/install');
	}

	
}