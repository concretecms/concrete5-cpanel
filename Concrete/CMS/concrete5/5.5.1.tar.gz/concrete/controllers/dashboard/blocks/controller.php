<?php 
defined('C5_EXECUTE') or die("Access Denied.");
class DashboardBlocksController extends Controller {

	public function view() {
		$this->redirect('/dashboard/blocks/stacks');
	}

	
}